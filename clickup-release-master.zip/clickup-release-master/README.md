# clickup-release
Desktop builds for [ClickUp](https://clickup.com/).

For support, please contact [help@clickup.com](mailto:help@clickup.com)
